# XAGameSpace VIP 1.0.0

A starter Android gaming utility for Android 7+.

## Build from GitHub Actions
Run **Build XAGameSpace VIP**. Download the `XAGameSpace-VIP-debug` artifact.

## Implemented in this starter
- Android dashboard
- Available/total RAM information
- Android thermal status where exposed (API 29+)
- Shizuku running-state and permission request
- Launcher-app picker and app launching
- Persisted X/Y profile sliders (app-local profile only)
- Basic overlay HUD with tap-to-close

## Not implemented / Android restrictions
- Global touchscreen X/Y sensitivity: not exposed to ordinary apps
- Cross-game FPS and GPU counters: device/OEM-specific access needed
- Texture LOD changes: game/driver-specific; no universal Android API
- Global macro/input injection: restricted and not provided here
- Automatic CPU/GPU overclocking or thermal-throttling disable: not provided
- Full automatic restore: no system settings are modified by this starter

This project intentionally avoids fake performance claims and destructive system tweaks.
