package com.xa.gamespace.vip

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class FloatingHudService : Service() {
    private var wm: WindowManager? = null
    private var view: TextView? = null

    override fun onCreate() {
        super.onCreate()
        if (!android.provider.Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        view = TextView(this).apply {
            text = "XA VIP  •  HUD\nTap to close"
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(225, 43, 27, 68))
            setPadding(22, 16, 22, 16)
            setOnClickListener { stopSelf() }
        }
        val type = if (android.os.Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 18; y = 170 }
        wm?.addView(view, params)
    }

    override fun onDestroy() {
        try { view?.let { wm?.removeView(it) } } catch (_: Throwable) {}
        view = null; wm = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
