package com.xa.gamespace.vip

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 11, 20)
    private val panel = Color.rgb(27, 28, 45)
    private val accent = Color.rgb(183, 124, 255)
    private lateinit var shizukuStatus: TextView
    private lateinit var metrics: TextView
    private lateinit var games: Spinner
    private val prefs by lazy { getSharedPreferences("vip_settings", MODE_PRIVATE) }
    private var gamePackages: List<String> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::shizukuStatus.isInitialized) refreshStatus()
        if (::metrics.isInitialized) refreshMetrics()
    }

    private fun render() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(28))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply { addView(content) }
        content.addView(text("XA  /  PREMIUM GAMING TOOLS", 11, accent))
        content.addView(text("XAGameSpace VIP", 28, Color.WHITE))
        content.addView(text("EXTREME EDITION  •  1.0.0", 11, Color.LTGRAY))
        content.addView(gap(16))

        content.addView(header("LIVE DEVICE STATUS"))
        metrics = text("Reading device information…", 13, Color.LTGRAY)
        content.addView(metrics)
        button(content, "Refresh monitoring", panel) { refreshMetrics() }

        content.addView(gap(12))
        content.addView(header("SHIZUKU / ADB ENGINE"))
        shizukuStatus = text("Checking Shizuku…", 13, Color.LTGRAY)
        content.addView(shizukuStatus)
        button(content, "Request Shizuku permission", panel) { requestShizuku() }
        button(content, "Open Shizuku app", panel) {
            val launch = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if (launch != null) startActivity(launch) else toast("Install Shizuku from its official website first.")
        }

        content.addView(gap(12))
        content.addView(header("GAME MANAGER"))
        gamePackages = findLaunchableGames()
        games = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                if (gamePackages.isEmpty()) listOf("No launchable apps found") else gamePackages)
        }
        content.addView(games)
        button(content, "Launch selected app", panel) {
            val selected = games.selectedItem?.toString()
            if (selected != null && gamePackages.contains(selected)) {
                val launch = packageManager.getLaunchIntentForPackage(selected)
                if (launch != null) startActivity(launch) else toast("Cannot launch this package.")
            }
        }

        content.addView(gap(12))
        content.addView(header("TOUCH X / Y PROFILE"))
        content.addView(text("These sliders save an in-app profile only. They do not change Android's global touchscreen driver.", 11, Color.LTGRAY))
        sensitivityControl(content, "X Sensitivity", "touch_x")
        sensitivityControl(content, "Y Sensitivity", "touch_y")
        button(content, "Save touch profile", panel) { toast("Touch profile saved on this device.") }

        content.addView(gap(12))
        content.addView(header("FLOATING HUD"))
        button(content, "Grant overlay permission", panel) {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else toast("Overlay permission is already granted.")
        }
        button(content, "Start floating HUD", panel) {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, FloatingHudService::class.java))
                toast("Floating HUD started. Tap it to close.")
            } else toast("Grant overlay permission first.")
        }
        button(content, "Stop floating HUD", panel) { stopService(Intent(this, FloatingHudService::class.java)) }

        content.addView(gap(12))
        content.addView(header("ADVANCED MODULES"))
        infoCard(content, "FPS / CPU / GPU", "Device/app-level monitoring only. Cross-game FPS and GPU counters depend on OEM access and are not universally exposed.")
        infoCard(content, "Texture LOD / Burik", "Not universally configurable by another app. Requires game-specific support or a compatible graphics driver.")
        infoCard(content, "Sensitivity Zones / Macro", "No global touch injection is enabled. Android restricts synthetic input; accessibility-based automation requires explicit user setup and may be blocked by games.")
        infoCard(content, "Restore System", "This build does not modify system performance settings, so it has no system changes to restore.")
        content.addView(gap(16))
        content.addView(text("No thermal throttling is disabled. Avoid tools claiming universal FPS unlocks.", 11, Color.GRAY))
        setContentView(scroll)
        refreshStatus()
        refreshMetrics()
    }

    private fun refreshStatus() {
        val running = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
        val granted = try { Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED } catch (_: Throwable) { false }
        shizukuStatus.text = when {
            running && granted -> "Shizuku connected • permission granted"
            running -> "Shizuku running • permission not granted"
            else -> "Shizuku not running • start it via Wireless Debugging"
        }
    }

    private fun requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                toast("Start Shizuku first using Wireless Debugging.")
                return
            }
            if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                toast("Shizuku permission already granted.")
            } else {
                Shizuku.requestPermission(42)
            }
            refreshStatus()
        } catch (t: Throwable) { toast("Shizuku error: ${t.message}") }
    }

    private fun refreshMetrics() {
        if (!::metrics.isInitialized) return
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val ramAvail = mi.availMem / 1024 / 1024
        val ramTotal = mi.totalMem / 1024 / 1024
        val thermal = if (android.os.Build.VERSION.SDK_INT >= 29) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            when (pm.currentThermalStatus) {
                0 -> "None"; 1 -> "Light"; 2 -> "Moderate"; 3 -> "Severe"
                4 -> "Critical"; 5 -> "Emergency"; 6 -> "Shutdown"; else -> "Unknown"
            }
        } else "Not exposed by Android version"
        metrics.text = "RAM available: ${ramAvail} MB / ${ramTotal} MB\nThermal status: $thermal\nAndroid: ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})"
    }

    private fun findLaunchableGames(): List<String> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .mapNotNull { it.activityInfo?.packageName }
            .distinct().sorted()
    }

    private fun sensitivityControl(parent: LinearLayout, title: String, key: String) {
        parent.addView(text("$title: ${prefs.getInt(key, 100)}%", 13, Color.WHITE))
        val seek = SeekBar(this).apply {
            max = 200
            progress = prefs.getInt(key, 100)
        }
        val value = TextView(this).apply { setTextColor(Color.LTGRAY); text = "${seek.progress}%" }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                value.text = "$p%"
                if (fromUser) prefs.edit().putInt(key, p).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(seek)
        parent.addView(value)
    }

    private fun infoCard(parent: LinearLayout, title: String, desc: String) {
        parent.addView(text(title, 14, Color.WHITE))
        parent.addView(text(desc, 11, Color.LTGRAY))
        parent.addView(gap(7))
    }

    private fun header(s: String) = text(s, 15, accent)
    private fun text(s: String, size: Int, color: Int) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color); setPadding(0, dp(6), 0, dp(6))
    }
    private fun button(parent: LinearLayout, title: String, color: Int, action: () -> Unit) {
        parent.addView(Button(this).apply {
            text = title; isAllCaps = false; setTextColor(Color.WHITE)
            setBackgroundColor(color); setOnClickListener { action() }
        }, LinearLayout.LayoutParams(-1, dp(49)).apply { bottomMargin = dp(6) })
    }
    private fun gap(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
